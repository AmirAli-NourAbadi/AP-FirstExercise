import view.Cli;

public class Main {
    public static void main(String[] args) {
        new Cli();
    }
}